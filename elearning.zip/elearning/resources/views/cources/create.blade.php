@extends('layouts.app')
@section('stylesheets')
<script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

    <script>
    $(document).ready(function(){
        var number = 0
        $('.clone_btn').click(function(){
            number++;
          $("#main_parents").append($("#parents").clone().addClass('Cloned_r_'+ number));
            $('.Cloned_r_'+number+ ' a').addClass('Cloned_r');
            $('#parents').addClass('parents');
            $('.Cloned_r_'+number+' a').removeClass('btn-success');
            $('.Cloned_r_'+number+' a').addClass('btn-danger');
            $('.Cloned_r_'+number+' i').removeClass('fa-plus');
            $('.Cloned_r_'+number+' i').addClass('fa-minus');
            $('.Cloned_r_'+number+' a').attr('onclick','$(this).parents("#parents").remove();');
            });
                  
    });
    $(document).ready(function(){
        var numbers = 0
        $('.clone_btn_s').click(function(){
            numbers++;
          $("#main_parents_out").append($("#parents_out").clone().addClass('Cloned_r_out_'+ numbers));
            $('.Cloned_r_out_'+numbers+ ' a').addClass('Cloned_r_out');
            $('#parents_out').addClass('parents_out');
            $('.Cloned_r_out_'+numbers+' a').removeClass('btn-success');
            $('.Cloned_r_out_'+numbers+' a').addClass('btn-danger');
            $('.Cloned_r_out_'+numbers+' i').removeClass('fa-plus');
            $('.Cloned_r_out_'+numbers+' i').addClass('fa-minus');
            $('.Cloned_r_out_'+numbers+' a').attr('onclick','$(this).parents("#parents_out").remove();');
            });
                  
    });
    </script>
     <script>
        $(".Cloned_r").click(function(event) {
  event.preventDefault();
   $(this).remove();
});
    
    </script>
   <script src='{{ asset('js/tinymce_mode.js') }}'></script>
<script>
    {!! \File::get(base_path('vendor/unisharp/laravel-filemanager/public/js/lfm.js')) !!}
      var route_prefix = "{{ url(config('lfm.url_prefix')) }}";
    $('#my1').filemanager('file', {prefix: route_prefix});
</script>
@endsection
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 ">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Create New Cource
                </div>

                <div class="card-body">
                  
                       
                      <ul class="nav nav-tabs border-0" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active border border-primary border-bottom-0" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><i class="fa fa-tasks" aria-hidden="true"></i> General</a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-info border-bottom-0" id="Requirments-tab" data-toggle="tab" href="#Requirments" role="tab" aria-controls="Requirments" aria-selected="false"><i class="fa fa-bell"></i> Requirments</a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-info border-bottom-0" id="Outcomes-tab" data-toggle="tab" href="#Outcomes" role="tab" aria-controls="Outcomes" aria-selected="false"><i class="fa fa-arrows"></i> Outcomes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-info border-bottom-0" id="Pricing-tab" data-toggle="tab" href="#Pricing" role="tab" aria-controls="Pricing" aria-selected="false"><i class="fa fa-rmb"></i> Pricing</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link border text-dark border-danger border-bottom-0" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false"><i class="fa fa-picture-o"></i> Media</a>
                        </li>
                        
                        
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-info border-bottom-0" id="Finish-tab" data-toggle="tab" href="#Finish" role="tab" aria-controls="Finish" aria-selected="false"><i class="fa fa-check-circle" aria-hidden="true"></i> Finish</a>
                        </li>
                    </ul>
            <form action="{{ route('cource.store') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                    <div class="tab-content h-75">
                        <div class="tab-pane h-100 p-3 active border border-primary" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="form-group">
                                <label for="name">Course Title</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="desc">Course Description</label>
                                <textarea name="desc" id="desc" ></textarea>
                            </div>
                            <div class="form-group">
                                <label for="short_desc">Course Short Description</label>
                                <textarea type="text" name="short_desc" id="short_desc" class="form-control" cols="30" rows="10"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="level">Level</label>
                                <select id="select2" class="form-control" name="state">
                                    @foreach($level as $le)
                                        <option value="{{ $le->id }}">{{ $le->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="tab-pane h-100 p-3 border border-danger" id="messages" role="tabpanel" aria-labelledby="messages-tab">
                            
                            <div class="form-group">
                                <label for="type">Select Media Type</label>
                                <select name="" id="type" class="form-control">
                                    <option value="Youtube">Youtube</option>
                                    <option value="vimo">vimo</option>
                                    <option value="Usv">Upload Intro Video</option>
                                    <option value="picture">picture</option>
                                </select>
                            </div>
                            <div class="form-group" id='embeded'>
                                <label for="embeded">embeded Url</label>
                                <input type="text" id="embeded" name="video_url" class="form-control">
                            </div>
                            <div id="v_upload" class="form-group">
                                <label for="video">Select Video</label>
                                <input type="file" name="video_url" id="video" class="form-control">
                            </div>
                   <div id="holder" style="margin-top:15px;max-height:100px;"></div>
        <h2 class="mt-4">Standalone File Button</h2>
        <div class="input-group">
          <span class="input-group-btn">
            <a id="lfm2" data-input="thumbnail2" data-preview="holder2" class="btn btn-primary text-white">
              <i class="fa fa-picture-o"></i> Choose
            </a>
          </span>
          <input id="thumbnail2" class="form-control" type="text" name="filepath">
        </div>
                 <img id="holder" style="margin-top:15px;max-height:100px;">
                            <img id="holder" style="margin-top:15px;max-height:100px;">
                        </div>
                        <div class="tab-pane h-100 p-3 border border-info" id="Requirments" role="tabpanel" aria-labelledby="Requirments-tab" id="">
                            <div id="main_parents">
                                <div class="form-group" id="parents">
                                    <label for="requirment">Requirment</label>
                                    <div class="row">
                                        <div class="col-sm-10"><input type="text" placeholder="provide a requirment" class="form-control" name="requirment[]"></div>
                                        <div class="col-sm-2"><a href="#" class="btn btn-success clone_btn"><i class="fa fa-plus"></i></a></div>
                                    </div>
                                </div>
                            </div>

                            
                        </div>
                        <div class="tab-pane h-100 p-3 border border-info" id="Outcomes" role="tabpanel" aria-labelledby="Outcomes-tab">
                            <div id="main_parents_out">
                                <div class="form-group" id="parents_out">
                                    <label for="outcome">Outcome</label>
                                    <div class="row">
                                        <div class="col-sm-10"><input type="text" class="form-control" name="outcome[]" placeholder="provide a outcome"></div>
                                        <div class="col-sm-2"><a href="#" class="btn btn-success clone_btn_s"><i class="fa fa-plus"></i></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane h-100 p-3 border border-info" id="Pricing" role="tabpanel" aria-labelledby="Pricing-tab">
                            
                        </div>
                        <div class="tab-pane h-100 p-3 border border-info" id="Finish" role="tabpanel" aria-labelledby="Finish-tab">
                            
                        </div>
                    </div>
                </div>
            </form>
                <div class="card-footer">
                </div>
            </div>
        </div>
    </div>
</div>
@stop()