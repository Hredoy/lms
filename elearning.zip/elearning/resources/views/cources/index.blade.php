@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 ">
            <div class="card">
                <div class="card-header bg-primary text-white">
					<div class="row">
						<div class="col-md-10">Cource</div>
						<div class="col-md-2"><a href="{{ route('cource.create') }}" class="btn btn-success"><i class="fa fa-plus"></i> Add Button</a></div>
					</div>
                </div>

                <div class="card-body">
                   
                </div>
            </div>
        </div>
    </div>
</div>

@stop()
