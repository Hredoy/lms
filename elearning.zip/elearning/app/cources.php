<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cources extends Model
{
    protected $table = 'cources';
}
