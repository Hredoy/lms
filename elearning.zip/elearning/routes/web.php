<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::get('/laravel-filemanager', '\UniSharp\LaravelFilemanager\controllers\LfmController@show'); Route::post('/laravel-filemanager/upload', '\Unisharp\Laravelfilemanager\controllers\UploadController@upload');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/cources/index', 'courcesController@index')->name('cource.index');
Route::get('/cources/create', 'courcesController@create')->name('cource.create');
Route::post('/cources/store', 'courcesController@store')->name('cource.store');