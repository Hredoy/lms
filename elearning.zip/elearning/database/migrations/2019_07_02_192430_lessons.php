<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Lessons extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lessons', function (Blueprint $table) {
             $table->increments('id');
            $table->string('name');
            $table->text('description');
            $table->integer('files_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->integer('cources_id')->unsigned();
            $table->timestamps();
            $table->softDeletes();
        });
        Schema::table('lessons', function($table) {
           $table->foreign('files_id')->references('id')->on('files');
           $table->foreign('user_id')->references('id')->on('users');
           $table->foreign('cources_id')->references('id')->on('cources');
       });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cources');
    }
}
