<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Files extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('files', function (Blueprint $table) {
            $table->increments('id');
            $table->string('type');
            $table->string('link');
            $table->integer('user_id')->unsigned();
            $table->integer('cources_id')->unsigned();
            $table->integer('lessons_id')->default(null);
            $table->timestamps();
            $table->softDeletes();
        });
        Schema::table('files', function($table) {
           $table->foreign('user_id')->references('id')->on('users');
           $table->foreign('cources_id')->references('id')->on('cources');
       });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       Schema::dropIfExists('cources');
    }
}
