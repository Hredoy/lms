<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\level;
use Faker\Generator as Faker;

$factory->define(level::class, function (Faker $faker) {
    return [
    	'name' => $faker->sentence($nbWords = 6, $variableNbWords = true),
    ];
});
