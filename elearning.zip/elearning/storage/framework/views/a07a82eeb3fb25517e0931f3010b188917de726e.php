<?php $__env->startSection('stylesheets'); ?>
<script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>
        tinymce.init({
            selector: '#desc',
            menubar: true
        });
    $('#select2').select2();
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 ">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Create New Cource
                </div>

                <div class="card-body">
                  
                       
                      <ul class="nav nav-tabs border-0" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active border border-primary border-bottom-0" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><i class="fa fa-bars" aria-hidden="true"></i> General</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-warning border-bottom-0" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><i class="fa fa-cog"></i> Category</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-danger border-bottom-0" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false">Messages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border text-dark border-info border-bottom-0" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="false">Settings</a>
                        </li>
                    </ul>
            <form action="#" enctype="multipart/form-data">
                    <div class="tab-content h-75">
                        <div class="tab-pane h-100 p-3 active border border-primary" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="form-group">
                                <label for="name">Course Title</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="desc">Course Description</label>
                                <textarea name="desc" id="desc" ></textarea>
                            </div>
                            <div class="form-group">
                                <label for="short_desc">Course Short Description</label>
                                <textarea type="text" name="short_desc" id="short_desc" class="form-control" cols="30" rows="10"></textarea>
                            </div>
                        </div>
                        <div class="tab-pane h-100 p-3 border border-warning" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="form-group">
                                <label for="level">Level</label>
                                <select id="select2" name="state">
                                  <option value="AL">Alabama</option>
                                    ...
                                  <option value="WY">Wyoming</option>
                                </select>
                            </div>
                        </div>
                        <div class="tab-pane h-100 p-3 border border-danger" id="messages" role="tabpanel" aria-labelledby="messages-tab">Message tab content...</div>
                        <div class="tab-pane h-100 p-3 border border-info" id="settings" role="tabpanel" aria-labelledby="settings-tab">Settings tab content...</div>
                    </div>
                </div>
            </form>
                <div class="card-footer">
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\elearning\resources\views/cources/create.blade.php ENDPATH**/ ?>